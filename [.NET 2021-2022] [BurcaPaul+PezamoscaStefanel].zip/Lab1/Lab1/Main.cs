﻿using System;

namespace Lab1
{
    class MainClass
    {
        static void Main(string[] args)
        {
           /* Manager manager = new Manager();
            manager.FirstName = "Gigica";
            manager.LastName = "Georgel";
            Console.WriteLine(manager.GetFullName());
            manager.StartDate = DateTime.Now;
            manager.EndDate = DateTime.Now.AddDays(2);
            Console.WriteLine(manager.IsActive());
            Console.WriteLine(manager.Salutation());
            Employee employee = new Architect();
            employee.FirstName = "Nicolae";
            employee.LastName = "Nicolau";
            Console.WriteLine(employee.Salutation());*/
            Console.Write("dsa das ddf".ComputeWords());

        }
    }
}
